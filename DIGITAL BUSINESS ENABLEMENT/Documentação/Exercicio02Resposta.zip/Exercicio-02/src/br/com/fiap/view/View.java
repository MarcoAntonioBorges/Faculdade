package br.com.fiap.view;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Scanner;

import br.com.fiap.exception.ResponseException;
import br.com.fiap.repository.VendaRepository;
import br.com.fiap.to.Venda;

public class View {

	private static VendaRepository rep = new VendaRepository();
	private static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		int opcao;
		
		do {
			System.out.println("0 - Sair");
			System.out.println("1 - Listar");
			System.out.println("2 - Buscar");
			System.out.println("3 - Cadastrar");
			System.out.println("4 - Atualizar");
			System.out.println("5 - Remover");
			System.out.print("Digite a op��o: ");
			opcao = sc.nextInt();

			System.out.println("\n");
			
			switch (opcao) {
			case 1:
				listar();
				break;
			case 2:
				buscar();
				break;
			case 3:
				cadastrar();
				break;
			case 4:
				atualizar();
				break;
			case 5:
				remover();
				break;
			case 0:
				System.out.println("Obrigado!");
				break;
			default:
				System.out.println("Op��o inv�lida");
				break;
			}
			
			
			System.out.println("\n--------------");
			
		} while (opcao != 0);

	}

	private static void remover() {

		System.out.println("Digite o c�digo: ");
		int codigo = sc.nextInt();

		try {
			rep.remover(codigo);
			System.out.println("Removido com sucesso!");
		} catch (ResponseException e) {
			e.printStackTrace();
		}

	}

	private static void atualizar() {

		try {
			Venda venda = lerVenda();

			System.out.print("Digite o c�digo: ");
			venda.setId(sc.nextInt());

			rep.atualizar(venda);
			System.out.println("Atualizado com sucesso");

		} catch (ResponseException e) {
			e.printStackTrace();
		}
	}

	private static void cadastrar() {

		try {
			Venda venda = lerVenda();
			rep.cadastrar(venda);

			System.out.println("Cadastrado com sucesso!");

		} catch (ResponseException e) {
			e.printStackTrace();
		}

	}

	private static void buscar() {

		System.out.println("Digite o c�digo: ");
		int codigo = sc.nextInt();

		try {
			Venda venda = rep.pesquisa(codigo);
			System.out.println(venda);
		} catch (ResponseException e) {
			e.printStackTrace();
		}

	}

	public static void listar() {

		try {
			List<Venda> lista = rep.listar();

			for (Venda venda : lista) {
				System.out.println(venda);
				System.out.println("******************");
			}

		} catch (ResponseException e) {
			e.printStackTrace();
		}

	}

	private static Venda lerVenda() {

		Venda venda = new Venda();
		System.out.print("Digite a descri��o: ");
		venda.setDescricao(sc.next() + sc.nextLine());

		System.out.print("Digite o valor: ");
		venda.setValor(sc.nextFloat());

		System.out.println("Digite a data: (dd/mm/yyyy)");
		String dataString = sc.next();

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Calendar data = Calendar.getInstance();
		try {
			data.setTime(sdf.parse(dataString));
			venda.setData(data);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		return venda;

	}

}