package br.com.fiap.desafio05;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText edtFrase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtFrase = findViewById(R.id.edtFrase);
    }

    public void verificar(View view) {

        String frase =
                edtFrase.getText().toString() // Pega o texto do componente
                        .toLowerCase() // Deixa tudo em minúsculo para comparação
                        .replaceAll("[^a-zA-Z0-9]", ""); // Remove tudo que não é letras ou números;

        String fraseInvertida = new StringBuffer(frase).reverse().toString(); // Frase invertida

        //
        // Compara as frases se mesmo invertida continua igual a original limpa
        //
        if ( fraseInvertida.equals(frase) ) {
            Toast.makeText(this, R.string.eh_um_palindromo, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, R.string.nao_eh_um_palindromo, Toast.LENGTH_SHORT).show();
        }
    }
}
