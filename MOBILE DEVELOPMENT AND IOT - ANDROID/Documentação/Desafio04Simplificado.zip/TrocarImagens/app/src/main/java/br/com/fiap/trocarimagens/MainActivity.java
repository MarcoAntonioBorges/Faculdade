package br.com.fiap.trocarimagens;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    ImageView img1;
    ImageView img2;

    int cont = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        img1 = findViewById(R.id.img1);
        img2 = findViewById(R.id.img2);
    }

    public void trocar(View view) {
        if ( cont == 0 ) {
            img1.setImageResource(R.drawable.quadrado);
            img2.setImageResource(R.drawable.triangulo);
            cont++;
        } else {
            img1.setImageResource(R.drawable.triangulo);
            img2.setImageResource(R.drawable.quadrado);
            cont = 0;
        }
    }
}
