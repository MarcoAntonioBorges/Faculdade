package br.com.fiap.nac01.RM00000;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    ImageView imgPessoa;

    int[] imagens = {
      R.drawable.p0,
      R.drawable.p1,
      R.drawable.p2,
      R.drawable.p3,
      R.drawable.p4,
      R.drawable.p5,
      R.drawable.p6
    };

    int cont = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imgPessoa = findViewById(R.id.imgPessoa);
    }

    public void anterior(View view) {
        cont--;

        if ( cont < 0 ) {
            cont = imagens.length - 1;
        }

        imgPessoa.setImageResource( imagens[cont] );
    }

    public void proxima(View view) {
        cont++;

        if ( cont >= imagens.length ) {
            cont = 0;
        }

        imgPessoa.setImageResource( imagens[cont] );
    }
}
