package br.com.fiap.desafio01;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText edtNumero1;
    EditText edtNumero2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializa os componentes
        edtNumero1 = findViewById(R.id.edtNumero1);
        edtNumero2 = findViewById(R.id.edtNumero2);
    }

    public void somar(View view) {

        String txtNumero1 = edtNumero1.getText().toString();
        String txtNumero2 = edtNumero2.getText().toString();

        // Verifica se algum dos textos está vazio
        if ( txtNumero1.trim().isEmpty() || txtNumero2.trim().isEmpty() ) {
            Toast.makeText(this, "Informe corretamente os números para somar!", Toast.LENGTH_SHORT).show();
            return; //mata o método aqui
        }


        // Converte as Strings para números inteiros
        int numero1 = Integer.valueOf(txtNumero1);
        int numero2 = Integer.valueOf(txtNumero2);

        int soma = numero1 + numero2; //Soma os números

        // Exibe a soma para o usuário
        Toast.makeText(this, "A soma dos números é: " + soma, Toast.LENGTH_SHORT).show();
    }
}
