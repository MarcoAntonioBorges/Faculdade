//
//  hello_world.m
//  TesteObjC
//
//  Created by Gustavo Calixto on 12/02/17.
//  Copyright © 2017 Gustavo Calixto. All rights reserved.
//

//Exemplo 1 - Hello World

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {

    //meu primeiro programa em Objective-C
    NSLog(@"\nHello, World!");
    return 0;
}
