package br.com.fiap.dao.impl;

import javax.persistence.EntityManager;

import br.com.fiap.dao.VeiculoDAO;
import br.com.fiap.entity.Veiculo;
import br.com.fiap.exception.CodigoInexistenteException;
import br.com.fiap.exception.CommitException;

public class VeiculoDAOImpl implements VeiculoDAO {

	private EntityManager em;
	
	public VeiculoDAOImpl(EntityManager em) {
		this.em = em;
	}
	
	public void cadastrar(Veiculo veiculo) {
		em.persist(veiculo);
	}

	public void remover(int codigo) throws CodigoInexistenteException {
		Veiculo veiculo = pesquisar(codigo);
		em.remove(veiculo);
	}

	public Veiculo pesquisar(int codigo) throws CodigoInexistenteException {
		Veiculo veiculo = em.find(Veiculo.class, codigo);
		if (veiculo == null) {
			throw new CodigoInexistenteException();
		}
		return veiculo;
	}

	public void alterar(Veiculo veiculo) {
		em.merge(veiculo);
	}

	public void commit() throws CommitException {
		try {
			em.getTransaction().begin();
			em.getTransaction().commit();
		}catch(Exception e) {
			e.printStackTrace();
			em.getTransaction().rollback();
			throw new CommitException("Erro no commit");
		}
	}

	
	
}