package br.com.fiap.dao.impl;

import javax.persistence.EntityManager;

import br.com.fiap.dao.MotoristaDAO;
import br.com.fiap.entity.Motorista;
import br.com.fiap.exception.CodigoInexistenteException;
import br.com.fiap.exception.CommitException;

public class MotoristaDAOImpl implements MotoristaDAO {

	private EntityManager em;
	
	public MotoristaDAOImpl(EntityManager em) {
		this.em = em;
	}
	
	public void cadastrar(Motorista motorista) {
		em.persist(motorista);
	}

	public void remover(long codigo) throws CodigoInexistenteException {
		Motorista motorista = pesquisar(codigo);
		em.remove(motorista);
	}

	public Motorista pesquisar(long codigo) throws CodigoInexistenteException {
		Motorista motorista = em.find(Motorista.class, codigo);
		if (motorista == null) {
			throw new CodigoInexistenteException();
		}
		return motorista;
	}

	public void alterar(Motorista motorista) {
		em.merge(motorista);
	}

	public void commit() throws CommitException {
		try {
			em.getTransaction().begin();
			em.getTransaction().commit();
		}catch(Exception e) {
			e.printStackTrace();
			em.getTransaction().rollback();
			throw new CommitException("Erro no commit");
		}
	}

	
	
}