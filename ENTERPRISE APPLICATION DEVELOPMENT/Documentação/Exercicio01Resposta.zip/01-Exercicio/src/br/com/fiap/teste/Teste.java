package br.com.fiap.teste;

import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import br.com.fiap.dao.MotoristaDAO;
import br.com.fiap.dao.VeiculoDAO;
import br.com.fiap.dao.impl.MotoristaDAOImpl;
import br.com.fiap.dao.impl.VeiculoDAOImpl;
import br.com.fiap.entity.Genero;
import br.com.fiap.entity.Motorista;
import br.com.fiap.entity.Veiculo;

public class Teste {

	public static void main(String[] args) {
		EntityManagerFactory fabrica = Persistence.createEntityManagerFactory("CLIENTE_ORACLE");
		EntityManager em = fabrica.createEntityManager();

		/*
		 * TESTE DO VEICULO
		 */
		VeiculoDAO veiculoDao = new VeiculoDAOImpl(em);

		try {

			// CADASTRO
			Veiculo veiculo = new Veiculo("ABC-1234", "Branco", 2010);
			veiculoDao.cadastrar(veiculo);
			veiculoDao.commit();
			System.out.println("CADASTRADO!");

			// ATUALIZA��O
			Veiculo veiculo2 = new Veiculo(veiculo.getCodigo(), "BCA-4321", "Prata", 2012);
			veiculoDao.alterar(veiculo2);
			veiculoDao.commit();
			System.out.println("ATUALIZADO!");

			// PESQUISA
			Veiculo busca = veiculoDao.pesquisar(veiculo.getCodigo());
			System.out.println(busca.getPlaca());

			// REMO��O
			veiculoDao.remover(veiculo.getCodigo());
			veiculoDao.commit();
			System.out.println("REMOVIDO!");

		} catch (Exception e) {
			e.printStackTrace();
		}

		/*
		 * TESTE DO MOTORISTA
		 */
		MotoristaDAO motoristaDao = new MotoristaDAOImpl(em);

		try {
			//CADASTRO
			Motorista motorista = new Motorista(456554654, "Teste", new GregorianCalendar(1990, Calendar.JANUARY, 20), null, Genero.FEMININO);
			motoristaDao.cadastrar(motorista);
			motoristaDao.commit();
			System.out.println("CADASTRADO!");
			
			//ATUALIZA��O
			Motorista motorista2 = new Motorista(456554654, "Teste Modificado", new GregorianCalendar(2000, Calendar.APRIL, 21), null, Genero.MASCULINO);
			motoristaDao.alterar(motorista2);
			motoristaDao.commit();
			System.out.println("ALTERADO!");
			
			//PESQUISA
			Motorista busca = motoristaDao.pesquisar(456554654);
			System.out.println(busca.getNome());
			
			//REMO��O
			motoristaDao.remover(456554654);
			motoristaDao.commit();
			System.out.println("REMOVIDO!");
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		em.close();
		fabrica.close();
	}

}
