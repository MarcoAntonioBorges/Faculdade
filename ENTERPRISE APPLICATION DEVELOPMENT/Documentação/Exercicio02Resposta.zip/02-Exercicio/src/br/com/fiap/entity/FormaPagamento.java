package br.com.fiap.entity;

public enum FormaPagamento {

	CREDITO, DEBITO, DINHEIRO;
	
}
