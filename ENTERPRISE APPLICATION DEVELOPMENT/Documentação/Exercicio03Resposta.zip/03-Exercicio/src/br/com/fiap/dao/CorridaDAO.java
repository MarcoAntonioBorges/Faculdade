package br.com.fiap.dao;

import br.com.fiap.entity.Corrida;

public interface CorridaDAO extends GenericDAO<Corrida, Integer>{

}
