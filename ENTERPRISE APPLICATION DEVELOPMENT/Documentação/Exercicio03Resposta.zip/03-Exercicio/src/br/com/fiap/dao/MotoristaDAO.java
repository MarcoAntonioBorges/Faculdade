package br.com.fiap.dao;

import br.com.fiap.entity.Motorista;

public interface MotoristaDAO extends GenericDAO<Motorista, Long>{

	
}



