package br.com.fiap.dao;

import br.com.fiap.entity.Passageiro;

public interface PassageiroDAO extends GenericDAO<Passageiro, Integer>{

}
