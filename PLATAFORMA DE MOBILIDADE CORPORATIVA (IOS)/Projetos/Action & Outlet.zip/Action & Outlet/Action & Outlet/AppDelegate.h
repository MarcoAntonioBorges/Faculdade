//
//  AppDelegate.h
//  Action & Outlet
//
//  Created by Usuário Convidado on 05/02/19.
//  Copyright © 2019 Marco A. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

