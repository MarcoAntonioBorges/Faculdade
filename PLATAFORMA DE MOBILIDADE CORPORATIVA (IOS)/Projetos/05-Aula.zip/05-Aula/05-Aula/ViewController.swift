//
//  ViewController.swift
//  05-Aula
//
//  Created by Usuário Convidado on 15/03/19.
//  Copyright © 2019 Usuário Convidado. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    
    
    @IBOutlet weak var tfName: UITextField!
    
    @IBOutlet weak var tfEmail: UITextField!
    
    @IBOutlet weak var tfTelefone: UITextField!
    
    @IBOutlet weak var lbMessage: UILabel!
    
    
    // Quando a tela esta carregando
    override func viewDidLoad() {
        super.viewDidLoad()
        print("Tela 1: viewDidLoad")
        lbMessage.text = ""
    }
    
    // Quando a tela esta aparecendo
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print("Tela 1: viewWillAppear")
    }
    
    // a tela apareceu
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        print("Tela 1: viewDidAppear")
    }
    
    // A tela vai desaparecer
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        print("Tela 1: viewWillDisappear")
    }
    
    // a tela desapareceu
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        print("Tela 1: viewDidDisappear")
    }

    
    
    
    //Methods
    @IBAction func btnCreateUser(_ sender: Any) {

        let name = tfName.text!
        
        lbMessage.text = "O usuario \(name) foi cadastrado com sucesso"
    }
}

