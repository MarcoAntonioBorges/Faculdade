//
//  BlueViewController.swift
//  NavegacaoImagens
//
//  Created by Usuário Convidado on 05/04/19.
//  Copyright © 2019 FIAP. All rights reserved.
//

import UIKit

class BlueViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func close(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
}
