//
//  YellowViewController.swift
//  NavegacaoImagens
//
//  Created by Usuário Convidado on 05/04/19.
//  Copyright © 2019 FIAP. All rights reserved.
//

import UIKit

class YellowViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    
    @IBAction func goBack(_ sender: Any) {
//        if let secondVC = navigationController?.viewControllers[1] {
//            navigationController?.popToViewController(secondVC, animated: true)
//        }
        
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func gotoFirstScreen(_ sender: Any) {
        navigationController?.popToRootViewController(animated: <#T##Bool#>)
    }
    
}
