var test: String = "Teste"
let isiPhoneTheBestMobileDevice: Bool = false


//Tupla
//var address = "Av. Paulista, 1000, 01311-010"
var address: (street: String, number: Int, zipcode: String) = ("Av. Paulista", 1000, "01311-010")
print("O meu CEP é \(address.zipcode)")

//print("Eu moro na \(address)")
//var number = address.number
//var zipcode = address.zipcode
//var street = address.street

//Decomposição de Tupla
var (street, _, zipcode) = address


//Optional
var driverLicense: String? = nil
//driverLicense = "56456"

//Jeito vida loka
//print(driverLicense!)

//Optional Binding
if let driverLicense = driverLicense {
    print(driverLicense)
}


//Operadores
//+, -, *, /, +=, -=, =, !, ==, !=, >, <, &&, ||, %

//Operador de Coalescência Nula (Nil Coalescing Operator)
var streetNumber = "700"
var number = Int(streetNumber) ?? 0


//Closed Range
//...

2 ... 10

//Half-Open Range
//..<

2..<10

//Estruturas de condição
//if else
let grade = 8.5
if grade >= 6.0 {
    print("Passou")
} else {
    print("Te vejo ano que vem")
}

//Switch
var letter = "O"
switch letter {
case "A":
    print("Vogal")
case "E":
    print("Vogal")
case "I":
    print("Vogal")
case "O":
    print("Vogal")
case "U":
    print("Vogal")
default:
    print("Consoante")
}

switch letter.uppercased() {
case "A"..."N":
    print("Primeira metade do alfabeto")
default:
    print("Segunda metade do alfabeto")
}

//While, Repeat While
var count = 1
while count < 10 {
    print(count)
    count += 1
}


//Controle de fluxo
//for in

for number in 1...50 {
    print(number)
}


for number in stride(from: 3, to: 100, by: 3) {
    number
}

//Coleções
//Array

var emptyArray: [String] = []
var shoppingList = ["Açúcar", "Tempero", "Tudo que há de bom", "Elemento X"]

//Total
shoppingList.count

//Vazio?
shoppingList.isEmpty

//Percorro o Array
for item in shoppingList {
    print(item)
}

//Acessando elementos
print(shoppingList[2])

//Removendo último
shoppingList.removeLast()

shoppingList[0] = "QQ coisa"

//Adicionando
shoppingList.append("Banana")

shoppingList.insert("Café", at: 2)

shoppingList.contains("Banana")

shoppingList.firstIndex(of: "Bananas")


shoppingList.sort()

//Dicionário

var states: [String: String] = [
    "SP": "São Paulo",
    "MG": "Minas Gerais",
    "BA": "Bahia",
    "PA": "Pará",
    "RJ": "Rio de Janeiro"
]

for (sigla, nome) in states {
    print(sigla, nome)
}

states["MG"] = nil

states["SP"] = "Seu Puto"

states["PE"] = "Pernambuco"

if let sp = states["SP"] {
    print(sp)
}

