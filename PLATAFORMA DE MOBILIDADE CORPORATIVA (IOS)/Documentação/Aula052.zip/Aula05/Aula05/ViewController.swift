//
//  ViewController.swift
//  Aula05
//
//  Created by Usuário Convidado on 15/03/19.
//  Copyright © 2019 FIAP. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var tfName: UITextField!
    @IBOutlet weak var lbMessage: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lbMessage.text = ""
    }
    
    @IBAction func createUser(_ sender: Any) {
        let name = tfName.text!
        lbMessage.text = "O usuário \(name) foi cadastrado com sucesso"
    }
    

}

