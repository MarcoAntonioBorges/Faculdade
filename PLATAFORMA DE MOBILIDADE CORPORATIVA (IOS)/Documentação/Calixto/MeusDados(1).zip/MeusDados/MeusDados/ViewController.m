//
//  ViewController.m
//  MeusDados
//
//  Created by Usuário Convidado on 12/02/19.
//  Copyright © 2019 Agesandro Scarpioni. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    nome.text =   @"Nome........";
    idade.text =  @"Idade.......";
    cidade.text = @"Cidade......";
    // Do any additional setup after loading the view, typically from a nib.
}


- (IBAction)exibir:(id)sender {
    //NSLog(@"Bom dia");
    nome.text = @"Agesandro";
    idade.text = @"18 anos";
    cidade.text = @"São Paulo";
    
}

- (IBAction)limpar:(id)sender {
    //podemos limpar assim:
   // nome.text =   @"";
   // idade.text =  @"";
   // cidade.text = @"";
    
    //ou chamar o método didLoad
    [self viewDidLoad];
}
@end
